#include <iostream>
using namespace std;
int main()
{
    int i,j,m,n,l,k;
    char ch1,ch2;
    cin >> ch1;
    cin >> ch2;
    cin >> n;
    cin >> l;
    k = 2*l;
    for (i=0;i<n;i++)
    {
        for (j=0;j<k*n;j++)
            if (i+(j%(2*n))==2*n-1 || ((i==(j%(2*n))))) cout << ch1; else
            if (i+(j%(2*n))==n-1 || ((i+n==(j%(2*n))))) cout << ch2; else
               cout << ".";
        cout << endl;
    }
    return 0;
}
