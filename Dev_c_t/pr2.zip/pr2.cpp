#include <iostream>
using namespace std;
int main()
{
    int k,d,i,n,mul,num;
    cin >> k;
    for (i=0;i<k;i++)
    {
      cin >> n;
      mul = 1;
      while (n%2==0) n/=2;
      d = 3;
      while (n>1)
      {
          num = 0;
          while (n%d==0) {n/=d; num++;}
          mul *= num+1;
          d+=2;
      }
      cout << mul-1 << endl;
    }
    return 0;
}
