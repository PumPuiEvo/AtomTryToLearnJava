#include <iostream>
using namespace std;
#include <mem.h>
#define maxi 500001
int main()
{
    short chk[maxi];
    memset(chk,1,sizeof(chk));
    int k,i,j,n,count;
    for (i=1;i<maxi;i*=2) chk[i] = 0;
    cin >> k;
    for (j=0;j<k;j++)
    {
      cin >> n;
      count = 0;
      for (i=3;i<=n/2;i++)
          if (chk[i]&&chk[n-i]) count++;
      cout << count << endl;
    }
    return 0;
}
